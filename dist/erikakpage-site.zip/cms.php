<?php
/**
 * Lite CMS core helpers — no framework, no dependencies.
 * Used by index.php (front site), admin.php (dashboard) and setup.php (installer).
 */

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

function cfg(): array {
    static $c;
    return $c ??= require __DIR__ . '/config.php';
}

function db(): PDO {
    static $pdo;
    if ($pdo) return $pdo;
    $c = cfg();
    if (($c['driver'] ?? 'mysql') === 'sqlite') {
        $pdo = new PDO('sqlite:' . $c['sqlite_path']);
    } else {
        $pdo = new PDO(
            "mysql:host={$c['host']};dbname={$c['name']};charset=utf8mb4",
            $c['user'],
            $c['pass']
        );
    }
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    return $pdo;
}

/* ---------- field manifest (pages → sections → fields, with defaults) ---------- */

function manifest(): array {
    static $m;
    return $m ??= require __DIR__ . '/fields.php';
}

/** Flat map of key => field definition (type, label, default). */
function fields_flat(): array {
    static $flat;
    if ($flat === null) {
        $flat = [];
        foreach (manifest() as $page) {
            foreach ($page['sections'] as $sec) {
                foreach ($sec['fields'] as $f) $flat[$f['k']] = $f;
            }
        }
    }
    return $flat;
}

/* ---------- curated photo library (photos.php) ---------- */

function photo_library(): array {
    static $p;
    return $p ??= require __DIR__ . '/photos.php';
}

/**
 * The photo set offered for an image field, or [] when the slot has no curated set.
 * Returns ['id' => '03', 'title' => 'Keynote & stage', 'photos' => [...]].
 */
function photo_set(string $k): array {
    $lib = photo_library();
    $slot = $lib['slots'][$k] ?? null;
    if (!$slot) return [];
    $set = $lib['libraries'][$slot['lib']] ?? null;
    if (!$set) return [];
    return ['id' => $slot['lib'], 'title' => $set['title'], 'photos' => $set['photos']];
}

/**
 * Focal point of a curated photo as "X Y" percentages, or '' when it has none.
 * This is where the subject's face is, so cropped slots keep the head in frame.
 */
function photo_focal(string $path): string {
    static $map;
    if ($map === null) {
        $map = [];
        foreach (photo_library()['libraries'] as $set) {
            foreach ($set['photos'] as $p) {
                if (($p['pos'] ?? '') !== '') $map[$p['f']] = $p['pos'];
            }
        }
    }
    return $map[$path] ?? '';
}

/**
 * The curated pick for a slot: the picture shown when nothing has been chosen.
 *
 * This is what lets photos.php be the one place a slot's default picture is
 * decided — fields.php no longer has to repeat the path.
 */
function photo_pick(string $k): string {
    $lib = photo_library();
    $slot = $lib['slots'][$k] ?? null;
    if (!$slot) return '';
    foreach ($lib['libraries'][$slot['lib']]['photos'] ?? [] as $p) {
        if (($p['r'] ?? '') === ($slot['pick'] ?? '')) return $p['f'];
    }
    return '';
}

/** True when the path is one of the curated photos — the whitelist for saving a pick. */
function photo_is_library_path(string $path): bool {
    foreach (photo_library()['libraries'] as $set) {
        foreach ($set['photos'] as $p) if ($p['f'] === $path) return true;
    }
    return false;
}

/* ---------- content ---------- */

/** All DB overrides, loaded once per request. */
function content_all(bool $refresh = false): array {
    static $all;
    if ($all === null || $refresh) {
        $all = [];
        try {
            foreach (db()->query('SELECT k, v FROM content') as $r) $all[$r['k']] = $r['v'];
        } catch (Throwable $e) {
            /* not installed yet — fall back to defaults */
        }
    }
    return $all;
}

/**
 * Value for a key: DB override if present, else the manifest default.
 *
 * A picture slot with no default in the manifest falls back to its curated pick
 * from photos.php, so a slot only renders empty when nothing anywhere has a
 * picture for it — not merely because fields.php was never filled in.
 */
function cms(string $k): string {
    $all = content_all();
    if (array_key_exists($k, $all)) return $all[$k];

    $field = fields_flat()[$k] ?? null;
    $d = $field['d'] ?? '';
    if ($d === '' && ($field['t'] ?? '') === 'image') return photo_pick($k);
    return $d;
}

function content_set(string $k, string $v): void {
    $driver = cfg()['driver'] ?? 'mysql';
    $sql = $driver === 'sqlite'
        ? 'INSERT OR REPLACE INTO content (k, v) VALUES (?, ?)'
        : 'INSERT INTO content (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)';
    db()->prepare($sql)->execute([$k, $v]);
    // Keep the request's cached copy in step with the table, so anything read
    // back after a save — the admin re-rendering its own form, for one — sees
    // what was just written rather than the values the page started with.
    content_all(true);
}

/* ---------- output helpers used by the template ---------- */

function esc(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

/** Text that may carry HTML entities, as plain text (for esc() or JSON). */
function plain_text(string $s): string {
    return trim(html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
}

/**
 * The site's own origin, with no trailing slash — for canonical links, Open
 * Graph URLs and the sitemap, all of which have to be absolute.
 *
 * Editable in the admin because it changes between the live domain and any
 * staging copy, and a canonical link pointing at the wrong host is worse than
 * none at all.
 */
function site_url(): string {
    $u = trim(cms('global.site-url'));
    if ($u === '') {
        $host = $_SERVER['HTTP_HOST'] ?? 'erikakpage.com';
        $scheme = (($_SERVER['HTTPS'] ?? '') === 'on' || ($_SERVER['SERVER_PORT'] ?? '') === '443') ? 'https' : 'http';
        $u = $scheme . '://' . $host;
    }
    return rtrim($u, '/');
}

/**
 * A media path as the browser should see it: root-relative.
 *
 * Stored paths are site-relative ("assets/photos/01/a1.jpg"), which a browser
 * resolves against the directory of the current URL. That is the same thing on
 * every flat page, but an article lives at /blog/<slug>, where the same string
 * would be looked for in /blog/assets/… and 404. Everything media_tag() and
 * audio_tag() emit therefore goes through here.
 */
function asset_url(string $p): string {
    $p = trim($p);
    if ($p === '' || preg_match('#^(?:[a-z][a-z0-9+.-]*:|//|/)#i', $p)) return $p;
    return '/' . $p;
}

/** An absolute URL for a path that begins with "/". */
function abs_url(string $path): string {
    return site_url() . ($path === '/' ? '/' : $path);
}

/** Escaped plain-text field. */
function cms_e(string $k): string {
    return esc(cms($k));
}

/** Rich (WYSIWYG) field — sanitized HTML allowed through. */
function cms_rich(string $k): string {
    return strip_bad(cms($k));
}

/**
 * Quill wraps everything in <p> blocks, but our rich fields live inside
 * existing tags (headlines, paragraphs). Unwrap single blocks and join
 * multiple blocks with double line breaks.
 */
function unwrap_quill(string $html): string {
    $html = trim($html);
    if (preg_match('#^(?:<p[^>]*>.*?</p>\s*)+$#is', $html)) {
        preg_match_all('#<p[^>]*>(.*?)</p>#is', $html, $m);
        $parts = array_map('trim', $m[1]);
        $parts = array_values(array_filter($parts, fn($x) => $x !== '' && $x !== '<br>'));
        return implode('<br><br>', $parts);
    }
    return $html;
}

/** Remove script-ish content from stored HTML. */
function strip_bad(string $html): string {
    $html = preg_replace('#<\s*(script|iframe|object|embed|style)[^>]*>.*?<\s*/\s*\1\s*>#is', '', $html);
    $html = preg_replace('/\son\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);
    $html = preg_replace('/(href|src)\s*=\s*(["\']?)\s*javascript:[^"\'>\s]*\2/i', '$1=$2#$2', $html);
    return $html;
}

/**
 * Parse a stored "posX posY zoom" adjustment into an inline style, or '' for defaults.
 *
 * With nothing saved for the slot, fall back to the photo's own focal point: slots
 * crop with object-fit:cover, so a portrait photo in a landscape slot would otherwise
 * be cropped through the middle and lose the head. A hand adjustment always wins.
 */
function adjust_style(string $k): string {
    $raw = content_all()[$k . '__adj'] ?? '';
    if ($raw === '') {
        $focal = photo_focal(cms($k));
        if ($focal === '') return '';
        $raw = $focal . ' 100';
    }
    $p = preg_split('/\s+/', trim($raw));
    $x = isset($p[0]) ? (float) $p[0] : 50;
    $y = isset($p[1]) ? (float) $p[1] : 50;
    $z = isset($p[2]) ? (float) $p[2] : 100;
    $x = max(0, min(100, $x));
    $y = max(0, min(100, $y));
    $z = max(100, min(400, $z));
    if ($x == 50 && $y == 50 && $z == 100) return '';
    if ($z <= 100) return sprintf('object-position:%s%% %s%%;', $x, $y);
    $scale = number_format($z / 100, 3);
    return sprintf('object-position:%s%% %s%%;transform:scale(%s);transform-origin:%s%% %s%%;', $x, $y, $scale, $x, $y);
}

/**
 * What each kind of picture box is actually worth downloading.
 *
 * A picture box is never the full width of the window — it is one column of a
 * three-up card grid, or one tile of a six-up strip. 'sizes' tells the browser
 * the real width so it can pick a small file instead of the biggest one.
 *
 * 'cap' is the widest file worth offering for that box: roughly twice the
 * largest size the box is ever laid out at. Without it a 3x phone screen pulls
 * a 1200px photo into a 350px card — sharper than the eye can resolve, and
 * three times the wait on a mobile connection.
 *
 * Keys match the slot's container class in index.php.
 */
const SLOT_SIZES = [
    'hero'   => ['(max-width:920px) 92vw, 40vw', 1200],  // landing headshot
    'media'  => ['(max-width:920px) 92vw, 44vw', 1200],  // two-column page hero
    'half'   => ['(max-width:920px) 92vw, 46vw', 1200],  // split / tall / wide / cutout
    'video'  => ['(max-width:920px) 92vw, 70vw', 1600],  // full-width video frame
    'card'   => ['(max-width:920px) 92vw, 30vw', 800],   // three-up resource & product cards
    'tile'   => ['(max-width:560px) 46vw, (max-width:920px) 31vw, 15vw', 800], // thumbnail strip
    'gal'    => ['(max-width:560px) 46vw, (max-width:920px) 46vw, 30vw', 800], // gallery masonry
    'article'=> ['(max-width:920px) 92vw, 720px', 1200], // blog cover & body pictures
];

/**
 * Pre-built WebP copies of a picture, as a srcset, plus its intrinsic size.
 *
 * tools/build-images.php writes assets/rimg/<width>/<path>.webp. When those
 * exist the browser is offered the whole ladder and downloads only the step it
 * needs; when they do not (a fresh upload, say) this returns nothing and the
 * original is served on its own, exactly as before.
 *
 * @return array{srcset:string, w:int, h:int}
 */
function img_variants(string $path, int $cap = 0): array {
    static $cache = [];
    $ck = $path . '|' . $cap;
    if (isset($cache[$ck])) return $cache[$ck];

    $out = ['srcset' => '', 'w' => 0, 'h' => 0];
    $abs = __DIR__ . '/' . ltrim($path, '/');
    if (is_file($abs) && ($size = @getimagesize($abs))) {
        $out['w'] = (int) $size[0];
        $out['h'] = (int) $size[1];
    }

    $rel = ltrim($path, '/');
    $set = [];
    foreach (glob(__DIR__ . '/assets/rimg/*/' . $rel . '.webp') as $file) {
        if (preg_match('#/assets/rimg/(\d+)/#', $file, $m)) {
            $set[(int) $m[1]] = asset_url('assets/rimg/' . $m[1] . '/' . $rel . '.webp');
        }
    }
    if ($set) {
        ksort($set);
        if ($cap > 0) {
            // Keep every step up to the cap, plus the first one past it so the
            // ladder still has a rung when a picture is smaller than the cap.
            $kept = [];
            foreach ($set as $w => $f) {
                $kept[$w] = $f;
                if ($w >= $cap) break;
            }
            $set = $kept;
        }
        $out['srcset'] = implode(', ', array_map(fn($w, $f) => esc($f) . ' ' . $w . 'w', array_keys($set), $set));
    }
    return $cache[$ck] = $out;
}

/**
 * Image/video slot: outputs media tag when a picture exists, empty string otherwise.
 *
 * Every page lives in one document (hidden with display:none), so media is lazy by
 * default — the browser only fetches what the visitor actually navigates to. Pass
 * $eager for the one above-the-fold picture on the landing page.
 *
 * $slot names the kind of box the picture sits in (see SLOT_SIZES) so the browser
 * can pick a file scaled for that box rather than downloading the full-size photo.
 */
/**
 * A video's displayed pixel size, read straight out of the MP4 header so the
 * browser can reserve the right shape before a single byte of video arrives.
 * Phone footage is normally stored landscape with a rotation matrix beside it,
 * so the matrix is read too and the sides swapped when it says the picture is
 * turned on its end. This is the video counterpart of img_variants().
 */
function video_meta(string $path): array {
    static $cache = [];
    if (isset($cache[$path])) return $cache[$path];

    $out = ['w' => 0, 'h' => 0];
    $abs = __DIR__ . '/' . ltrim($path, '/');
    if (is_file($abs) && ($fh = @fopen($abs, 'rb'))) {
        $head = fread($fh, 262144);
        fclose($fh);
        // A file has one tkhd per track. The sound track carries 0x0, so keep
        // looking until a track reports a real picture size.
        $at = 0;
        while (($at = strpos($head, 'tkhd', $at)) !== false) {
            $box  = $at - 4;                        // step back over the box length
            $ver  = ord($head[$box + 8]);
            $skip = $ver === 1 ? 32 : 20;           // v1 stores 64-bit timestamps
            $mtx  = $box + 28 + $skip;              // 3x3 display matrix
            $dim  = $mtx + 36;                      // then width, then height
            $at  += 4;
            if ($box < 0 || strlen($head) < $dim + 8) continue;
            $a  = unpack('N', substr($head, $mtx, 4))[1];
            $b  = unpack('N', substr($head, $mtx + 4, 4))[1];
            $w  = unpack('N', substr($head, $dim, 4))[1] >> 16;      // 16.16 fixed
            $h  = unpack('N', substr($head, $dim + 4, 4))[1] >> 16;
            if ($a === 0 && $b !== 0) [$w, $h] = [$h, $w];           // quarter turn
            if ($w > 0 && $h > 0) { $out = ['w' => $w, 'h' => $h]; break; }
        }
    }
    return $cache[$path] = $out;
}

/** assets/video/clip.mp4 -> assets/video/clip.poster.webp, when that frame exists. */
function video_poster(string $path): string {
    $guess = preg_replace('/\.[^.]+$/', '.poster.webp', $path);
    return is_file(__DIR__ . '/' . ltrim($guess, '/')) ? $guess : '';
}

function cms_img(string $k, bool $eager = false, string $slot = 'half'): string {
    $v = cms($k);
    if ($v === '') return '';
    return media_tag($v, fields_flat()[$k]['label'] ?? '', $eager, $slot, adjust_style($k));
}

/**
 * Render one picture or video file as a tag. Split out of cms_img() so the
 * gallery, whose items are stored as plain paths rather than named fields, gets
 * exactly the same responsive images, posters and sizing rules.
 */
function media_tag(string $v, string $alt = '', bool $eager = false, string $slot = 'half', string $style = ''): string {
    $styleAttr = $style !== '' ? ' style="' . esc($style) . '"' : '';
    $ext = strtolower(pathinfo($v, PATHINFO_EXTENSION));
    if (in_array($ext, ['mp4', 'webm'], true)) {
        $m = video_meta($v);
        $dimAttr = $m['w'] > 0 ? ' width="' . $m['w'] . '" height="' . $m['h'] . '"' : '';
        $poster  = video_poster($v);
        $posterAttr = $poster !== '' ? ' poster="' . esc(asset_url($poster)) . '"' : '';
        return '<video src="' . esc(asset_url($v)) . '"' . $dimAttr . $posterAttr
            . ' autoplay muted loop playsinline preload="metadata"' . $styleAttr . '></video>';
    }

    [$sizes, $cap] = SLOT_SIZES[$slot] ?? SLOT_SIZES['half'];
    $var = img_variants($v, $cap);
    $srcAttr = '';
    if ($var['srcset'] !== '') {
        $srcAttr = ' srcset="' . $var['srcset'] . '" sizes="' . esc($sizes) . '"';
    }
    // Intrinsic size keeps the picture's own proportions known to the browser, so a
    // slow-loading photo never shifts the text underneath it.
    $dimAttr = $var['w'] > 0 ? ' width="' . $var['w'] . '" height="' . $var['h'] . '"' : '';
    $loading = $eager ? ' fetchpriority="high" decoding="async"' : ' loading="lazy" decoding="async"';

    return '<img src="' . esc(asset_url($v)) . '"' . $srcAttr . $dimAttr
        . ' alt="' . esc($alt) . '"' . $loading . $styleAttr . '>';
}

/* ---------- gallery ----------
 * The gallery is the one part of the site with no fixed number of slots: Erika
 * adds as many pictures as she likes from the admin. The whole list therefore
 * lives as one JSON value in the content table rather than as named fields, so
 * growing it never needs a code change or a database migration.
 */

/** Category id => the label printed on its filter chip. */
const GALLERY_CATS = [
    'listings'  => 'Listings',
    'sold'      => 'Sold',
    'speaking'  => 'Speaking',
    'lifestyle' => 'Lifestyle',
    'atlanta'   => 'Atlanta',
    'video'     => 'Videos',
    'bts'       => 'Behind the Scenes',
];

/** Shapes a gallery tile may take; the mixed heights are what makes the grid read well. */
const GALLERY_RATIOS = ['3/4', '4/3', '1/1', '16/9'];

/**
 * The gallery as it stands before anyone has arranged their own. Reads the
 * original fifteen fixed slots so the pictures already chosen for the site (and
 * any swap made in the admin since) carry straight over on the first load.
 */
function gallery_seed(): array {
    $seed = [
        ['img-luxury-listing-exterio',  'cap1',  '3/4',  'listings'],
        ['img-erika-on-stage',          'cap2',  '4/3',  'speaking'],
        ['img-sold-family-home',        'cap3',  '1/1',  'sold'],
        ['img-video-speaker-reel',      'cap4',  '16/9', 'video'],
        ['img-atlanta-skyline-at-dus',  'cap5',  '3/4',  'atlanta'],
        ['img-staged-interior-living',  'cap6',  '4/3',  'listings'],
        ['img-erika-editorial-portra',  'cap7',  '3/4',  'lifestyle'],
        ['img-video-client-story',      'cap8',  '16/9', 'video'],
        ['img-peachtree-city-golf-ca',  'cap9',  '4/3',  'atlanta'],
        ['img-closing-day-keys-hando',  'cap10', '1/1',  'sold'],
        ['img-luxury-kitchen-detail',   'cap11', '3/4',  'listings'],
        ['img-panel-discussion',        'cap12', '4/3',  'speaking'],
        ['img-lifestyle-shoot-atlant',  'cap13', '1/1',  'lifestyle'],
        ['img-video-erika-explains-b',  'cap14', '16/9', 'bts'],
        ['img-sold-gwinnett-colonial',  'cap15', '3/4',  'sold'],
    ];

    $out = [];
    foreach ($seed as [$img, $cap, $ar, $cat]) {
        $src = cms('gallery.section-2.' . $img);
        if ($src === '') continue;   // an unfilled slot is not a gallery picture
        $out[] = [
            'src' => $src,
            'cap' => cms('gallery.section-2.' . $cap),
            'ar'  => $ar,
            'cat' => $cat,
        ];
    }
    $out[] = [
        'src' => 'assets/photos/08/a6-lets-make-a-deal.jpg',
        'cap' => "Let's make a deal",
        'ar'  => '3/4',
        'cat' => 'sold',
    ];
    return $out;
}

/**
 * A gallery path is only ever a file that lives with the site. The list is
 * posted back from a form, so the path is re-checked on the way in rather than
 * trusted, and anything pointing outside assets/ or uploads/ is dropped.
 */
function gallery_safe_src(string $p): string {
    $p = ltrim(trim($p), '/');
    if ($p === '' || strpos($p, '..') !== false) return '';
    if (!preg_match('#^(assets|uploads)/[A-Za-z0-9._/\-]+$#', $p)) return '';
    return is_file(__DIR__ . '/' . $p) ? $p : '';
}

/**
 * True for the fifteen fixed slots (and their captions) that the gallery list
 * replaced. They still seed the list on a first load, so the fields stay in the
 * manifest — but the admin hides them, because the gallery is edited on its own
 * screen now. Deliberately narrow: the section also holds the paragraph and the
 * button under the grid, and those are still ordinary page copy.
 */
function gallery_grid_field(string $k): bool {
    return str_starts_with($k, 'gallery.section-2.img-')
        || (bool) preg_match('/^gallery\.section-2\.cap\d+$/', $k);
}

/** Every gallery picture, in display order. */
function gallery_items(): array {
    $raw = setting('gallery.items', '');
    if ($raw !== '') {
        $list = json_decode($raw, true);
        if (is_array($list)) {
            $out = [];
            foreach ($list as $i) {
                if (!is_array($i)) continue;
                $src = gallery_safe_src((string) ($i['src'] ?? ''));
                if ($src === '') continue;
                $out[] = [
                    'src' => $src,
                    'cap' => (string) ($i['cap'] ?? ''),
                    'ar'  => in_array($i['ar'] ?? '', GALLERY_RATIOS, true) ? $i['ar'] : '3/4',
                    'cat' => isset(GALLERY_CATS[$i['cat'] ?? '']) ? $i['cat'] : '',
                ];
            }
            return $out;
        }
    }
    return gallery_seed();
}

function gallery_items_save(array $items): void {
    set_setting('gallery.items', json_encode(array_values($items), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}

/* ---------- blog ----------
 * Posts behave like the gallery rather than like a page: there is no fixed
 * number of them, so the whole list lives as one JSON value in the content
 * table and growing it never needs a code change or a migration.
 *
 * The one difference from the gallery is that a post can also ship in a file.
 * posts.php is the default list, exactly as fields.php is the default for page
 * copy — which means an article can be published by uploading files, with no
 * database write at all. The two lists are merged by slug: the admin's copy of
 * a post wins, a post that exists only in the file is appended, and a post
 * removed in the admin is remembered in 'blog.removed' so it stays removed.
 */

/** Category id => the label printed on its filter chip and in the meta line. */
const BLOG_CATS = [
    'buying'    => 'Buying',
    'selling'   => 'Selling',
    'investing' => 'Investing',
    'market'    => 'Atlanta Market',
    'lifestyle' => 'Lifestyle',
];

/** The posts that ship with the site. */
function blog_seed(): array {
    static $seed;
    if ($seed === null) {
        $file = __DIR__ . '/posts.php';
        $seed = is_file($file) ? (array) require $file : [];
    }
    return $seed;
}

/** Title -> url-safe slug, for a post created in the admin. */
function blog_slugify(string $s): string {
    $s = strtolower(trim(html_entity_decode($s, ENT_QUOTES, 'UTF-8')));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim((string) $s, '-');
}

/**
 * One post, cleaned up on the way out of storage.
 *
 * Everything is re-checked here rather than trusted, because a row may have
 * come from a form: paths must point at a file that lives with the site, the
 * category must be a known one, and the date must be a date.
 */
function blog_clean(array $p): ?array {
    $slug = blog_slugify((string) ($p['slug'] ?? ''));
    if ($slug === '') $slug = blog_slugify((string) ($p['title'] ?? ''));
    if ($slug === '') return null;

    $date = trim((string) ($p['date'] ?? ''));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');
    $updated = trim((string) ($p['updated'] ?? ''));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $updated)) $updated = $date;

    $faq = [];
    foreach ((array) ($p['faq'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $q = trim((string) ($row['q'] ?? ''));
        $a = trim((string) ($row['a'] ?? ''));
        if ($q !== '' && $a !== '') $faq[] = ['q' => $q, 'a' => strip_bad($a)];
    }

    $tags = [];
    foreach ((array) ($p['tags'] ?? []) as $t) {
        $t = trim((string) $t);
        if ($t !== '') $tags[] = $t;
    }

    return [
        'slug'         => $slug,
        // Plain-text fields: printed through esc() and json_encode(), so an
        // entity written in posts.php (&rsquo;, &mdash;) is decoded here once —
        // otherwise it shows on the page as the literal text "&rsquo;".
        'title'        => plain_text((string) ($p['title'] ?? $slug)),
        'seo_title'    => plain_text((string) ($p['seo_title'] ?? '')),
        'seo_desc'     => plain_text((string) ($p['seo_desc'] ?? '')),
        'excerpt'      => plain_text((string) ($p['excerpt'] ?? '')),
        'date'         => $date,
        'updated'      => $updated,
        'author'       => trim((string) ($p['author'] ?? 'Erika K. Page')),
        'cat'          => isset(BLOG_CATS[$p['cat'] ?? '']) ? (string) $p['cat'] : '',
        'tags'         => $tags,
        'cover'        => gallery_safe_src((string) ($p['cover'] ?? '')),
        'cover_alt'    => plain_text((string) ($p['cover_alt'] ?? '')),
        'cover_credit' => strip_bad(trim((string) ($p['cover_credit'] ?? ''))),
        'audio'        => gallery_safe_src((string) ($p['audio'] ?? '')),
        // A downloadable companion (PDF). Validated the same way as the other
        // paths: it must be a file that lives with the site.
        'guide'        => gallery_safe_src((string) ($p['guide'] ?? '')),
        // The digital product this article's guide is, by slug. One field joins
        // the two records, which is what stops them describing each other
        // wrongly: the article's offer card takes its cover, name and page count
        // from the product, and the product page finds its article by looking for
        // the post that names it. Left empty, the article simply offers the PDF
        // at `guide` with no product behind it.
        'product'      => blog_slugify((string) ($p['product'] ?? '')),
        // A short, sayable path that redirects here — so a video can say
        // "go to erikakpage.com/closing-costs-101" rather than reading out a slug.
        'short'        => blog_slugify((string) ($p['short'] ?? '')),
        'audio_secs'   => max(0, (int) ($p['audio_secs'] ?? 0)),
        // What the line under the audio player says. Empty means the default
        // "same words, read aloud" — true only when the audio is the article
        // narrated. A podcast episode written as its own script says so here.
        'audio_note'   => plain_text((string) ($p['audio_note'] ?? '')),
        // A browser submits a textarea with CRLF line endings; normalising them
        // keeps a saved body byte-identical to the same text written in a file.
        'body'         => str_replace("\r\n", "\n", (string) ($p['body'] ?? '')),
        'faq'          => $faq,
        'published'    => !empty($p['published']),
    ];
}

/** Slugs removed in the admin, so a deleted post does not come back from the file. */
function blog_removed(): array {
    $raw = setting('blog.removed', '');
    $list = $raw === '' ? [] : json_decode($raw, true);
    return is_array($list) ? array_map('strval', $list) : [];
}

/**
 * Every post, newest first.
 *
 * @param bool $drafts include posts that are not published yet (the admin does)
 */
function blog_posts(bool $drafts = false): array {
    $out = [];

    $raw = setting('blog.posts', '');
    if ($raw !== '') {
        $list = json_decode($raw, true);
        if (is_array($list)) {
            foreach ($list as $p) {
                if (!is_array($p)) continue;
                $c = blog_clean($p);
                if ($c) $out[$c['slug']] = $c;
            }
        }
    }

    $removed = blog_removed();
    foreach (blog_seed() as $p) {
        if (!is_array($p)) continue;
        $c = blog_clean($p);
        if (!$c) continue;
        if (isset($out[$c['slug']]) || in_array($c['slug'], $removed, true)) continue;
        $out[$c['slug']] = $c;
    }

    if (!$drafts) $out = array_filter($out, fn($p) => $p['published']);

    $out = array_values($out);
    usort($out, fn($a, $b) => [$b['date'], $b['slug']] <=> [$a['date'], $a['slug']]);
    return $out;
}

/** One published post by slug, or null. */
function blog_post(string $slug, bool $drafts = false): ?array {
    foreach (blog_posts($drafts) as $p) {
        if ($p['slug'] === $slug) return $p;
    }
    return null;
}

function blog_posts_save(array $posts): void {
    set_setting('blog.posts', json_encode(array_values($posts), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}

function blog_removed_save(array $slugs): void {
    set_setting('blog.removed', json_encode(array_values(array_unique($slugs)), JSON_UNESCAPED_SLASHES));
}

/**
 * Article body, ready to print.
 *
 * Sanitized like any other stored HTML, then [[img:path|alt|credit]] tokens are
 * replaced with a real <figure>. Pictures go through media_tag() so a body
 * picture gets the same responsive ladder, lazy loading and intrinsic size as
 * every other picture on the site.
 */
function blog_body_html(string $body): string {
    $html = strip_bad($body);
    return (string) preg_replace_callback(
        '/\[\[img:([^\|\]]+)(?:\|([^\|\]]*))?(?:\|([^\]]*))?\]\]/',
        function (array $m): string {
            $src = gallery_safe_src($m[1]);
            if ($src === '') return '';
            $alt    = trim($m[2] ?? '');
            $credit = trim($m[3] ?? '');
            $fig  = '<figure class="art-fig">' . media_tag($src, $alt, false, 'article');
            if ($credit !== '') $fig .= '<figcaption>' . strip_bad($credit) . '</figcaption>';
            return $fig . '</figure>';
        },
        $html
    );
}

/**
 * FAQ list <-> the plain text the admin edits.
 *
 * One question per block: the first line is the question, the rest is the
 * answer, blocks separated by a blank line. Chosen over a grid of paired inputs
 * because it survives adding and removing questions without renumbering.
 */
function blog_faq_to_text(array $faq): string {
    $out = [];
    foreach ($faq as $f) $out[] = trim($f['q']) . "\n" . trim($f['a']);
    return implode("\n\n", $out);
}

function blog_faq_from_text(string $t): array {
    $out = [];
    foreach (preg_split('/\R{2,}/', str_replace("\r\n", "\n", trim($t))) as $blk) {
        $lines = preg_split('/\R/', trim($blk));
        $q = trim(array_shift($lines) ?? '');
        $a = trim(implode(' ', array_map('trim', $lines)));
        if ($q !== '' && $a !== '') $out[] = ['q' => $q, 'a' => $a];
    }
    return $out;
}

/**
 * How long an MP3 runs, in seconds, so the player and the page's schema can say
 * so without anyone typing it in.
 *
 * Reads the first frame header for the bitrate and, when the file carries a
 * Xing/Info header, the exact frame count. A variable-bitrate file without that
 * header can only be estimated, which is why the admin keeps an editable field.
 */
function mp3_duration(string $path): int {
    $abs = __DIR__ . '/' . ltrim($path, '/');
    if (!is_file($abs) || !($fh = @fopen($abs, 'rb'))) return 0;
    $size = filesize($abs);
    $head = fread($fh, 65536);
    fclose($fh);

    // Skip an ID3v2 tag if there is one.
    $off = 0;
    if (strncmp($head, 'ID3', 3) === 0 && strlen($head) > 10) {
        $b = array_map('ord', str_split(substr($head, 6, 4)));
        $off = 10 + (($b[0] & 0x7F) << 21 | ($b[1] & 0x7F) << 14 | ($b[2] & 0x7F) << 7 | ($b[3] & 0x7F));
    }

    // First frame sync.
    $pos = strpos($head, "\xFF", $off);
    while ($pos !== false && $pos + 4 <= strlen($head)) {
        $h = array_map('ord', str_split(substr($head, $pos, 4)));
        if (($h[1] & 0xE0) === 0xE0) {
            static $rates = [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0];
            static $srs   = [44100, 48000, 32000];
            $bitrate = $rates[($h[2] >> 4) & 0x0F] * 1000;
            $sr      = $srs[($h[2] >> 2) & 0x03] ?? 0;
            if ($bitrate > 0 && $sr > 0) {
                // Xing / Info frame count is exact when present.
                $tail = substr($head, $pos, 2048);
                $x = strpos($tail, 'Xing');
                if ($x === false) $x = strpos($tail, 'Info');
                if ($x !== false) {
                    $flags = unpack('N', substr($tail, $x + 4, 4))[1] ?? 0;
                    if ($flags & 1) {
                        $frames = unpack('N', substr($tail, $x + 8, 4))[1] ?? 0;
                        $spf = ($h[1] & 0x18) === 0x18 ? 1152 : 576; // MPEG1 vs MPEG2 layer III
                        if ($frames > 0) return (int) round($frames * $spf / $sr);
                    }
                }
                return (int) round(max(0, $size - $off) * 8 / $bitrate);
            }
        }
        $pos = strpos($head, "\xFF", $pos + 1);
    }
    return 0;
}

/** Minutes to read, rounded up, from the body's word count. */
function blog_reading_time(string $html): int {
    $words = str_word_count(strip_tags(preg_replace('/\[\[img:[^\]]*\]\]/', '', $html)));
    return max(1, (int) ceil($words / 220));
}

/** Seconds as an ISO-8601 duration, for the AudioObject in the page's schema. */
function iso_duration(int $secs): string {
    if ($secs <= 0) return '';
    return sprintf('PT%dM%dS', intdiv($secs, 60), $secs % 60);
}

/** mm:ss, for the label on the audio player. */
function clock_duration(int $secs): string {
    return $secs > 0 ? sprintf('%d:%02d', intdiv($secs, 60), $secs % 60) : '';
}

/**
 * An audio file as a player.
 *
 * Deliberately not part of media_tag(): that is for the site's picture slots,
 * and an audio path landing in one should stay an obvious mistake rather than
 * silently rendering something.
 */
function audio_tag(string $path, string $label = ''): string {
    if ($path === '') return '';
    return '<audio controls preload="metadata" src="' . esc(asset_url($path)) . '"'
        . ($label !== '' ? ' title="' . esc($label) . '"' : '') . '></audio>';
}

/* ---------- digital products ----------
 * Same shape as the blog: a list rather than a fixed set of fields, shipped in
 * products.php so a product can go live by uploading files, and overridden by
 * whatever is saved in the admin.
 *
 * A product is only ever advertised when it is published AND has a file behind
 * it. The page this replaced described six products that did not exist, with
 * six buttons that opened a mock-up alert — so "nothing is offered unless it is
 * real" is the rule this list exists to enforce.
 */

/** Category id => the label on its filter chip. */
const PRODUCT_CATS = [
    'seller'   => 'Home Seller',
    'buyer'    => 'Buyer & Relocation',
    'agent'    => 'Agent Tools',
    'wealth'   => 'Wealth / Investing',
    'mindset'  => 'Mindset / Reinvention',
    'workshop' => 'Workshops',
];

/** The products that ship with the site. */
function product_seed(): array {
    static $seed;
    if ($seed === null) {
        $file = __DIR__ . '/products.php';
        $seed = is_file($file) ? (array) require $file : [];
    }
    return $seed;
}

function product_clean(array $p): ?array {
    // Copy is stored as plain text and escaped on output. The seed file may be
    // written with entities (&rsquo;, &amp;) because it is HTML-ish to read, so
    // they are decoded here — otherwise the admin shows a human "&rsquo;" to
    // edit, and a second escape on output turns it into visible mark-up.
    $t = fn($v) => trim(html_entity_decode((string) $v, ENT_QUOTES, 'UTF-8'));

    $slug = blog_slugify((string) ($p['slug'] ?? ''));
    if ($slug === '') $slug = blog_slugify((string) ($p['title'] ?? ''));
    if ($slug === '') return null;

    $inside = [];
    foreach ((array) ($p['inside'] ?? []) as $i) {
        $i = $t($i);
        if ($i !== '') $inside[] = $i;
    }
    $faq = [];
    foreach ((array) ($p['faq'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $q = trim((string) ($row['q'] ?? ''));
        $a = trim((string) ($row['a'] ?? ''));
        if ($q !== '' && $a !== '') $faq[] = ['q' => $q, 'a' => strip_bad($a)];
    }

    return [
        'slug'      => $slug,
        'title'     => $t($p['title'] ?? $slug),
        'aud'       => $t($p['aud'] ?? ''),
        'cat'       => isset(PRODUCT_CATS[$p['cat'] ?? '']) ? (string) $p['cat'] : '',
        'prob'      => $t($p['prob'] ?? ''),
        'text'      => $t($p['text'] ?? ''),
        'intro'     => $t($p['intro'] ?? ''),
        'inside'    => $inside,
        'faq'       => $faq,
        'cover'     => gallery_safe_src((string) ($p['cover'] ?? '')),
        'cover_alt' => $t($p['cover_alt'] ?? ''),
        'file'      => gallery_safe_src((string) ($p['file'] ?? '')),
        'pages'     => max(0, (int) ($p['pages'] ?? 0)),
        'btn'       => $t($p['btn'] ?? '') ?: 'See what\'s inside',
        'short'     => blog_slugify((string) ($p['short'] ?? '')),
        'published' => !empty($p['published']),
    ];
}

/** Slugs removed in the admin, so a deleted product does not return from the file. */
function products_removed(): array {
    $raw = setting('products.removed', '');
    $list = $raw === '' ? [] : json_decode($raw, true);
    return is_array($list) ? array_map('strval', $list) : [];
}

/**
 * Every product, in the order they are listed.
 *
 * @param bool $drafts include unpublished ones (the admin does; the site does not)
 */
function products_all(bool $drafts = false): array {
    $out = [];

    $raw = setting('products.items', '');
    if ($raw !== '') {
        $list = json_decode($raw, true);
        if (is_array($list)) {
            foreach ($list as $p) {
                if (!is_array($p)) continue;
                $c = product_clean($p);
                if ($c) $out[$c['slug']] = $c;
            }
        }
    }

    $removed = products_removed();
    foreach (product_seed() as $p) {
        if (!is_array($p)) continue;
        $c = product_clean($p);
        if (!$c) continue;
        if (isset($out[$c['slug']]) || in_array($c['slug'], $removed, true)) continue;
        $out[$c['slug']] = $c;
    }

    // A published product with no file behind it would be an advertisement for
    // something nobody can actually get. It stays a draft until the file exists.
    if (!$drafts) $out = array_filter($out, fn($p) => $p['published'] && $p['file'] !== '');

    return array_values($out);
}

function product_one(string $slug, bool $drafts = false): ?array {
    foreach (products_all($drafts) as $p) {
        if ($p['slug'] === $slug) return $p;
    }
    return null;
}

/**
 * The published article whose guide is this product, or null.
 *
 * The join lives on the post (`product`), so this is the reverse direction: it
 * answers "is there an article about this guide?" for the product page. Reading
 * it from the same single field is the point — a product cannot end up pointing
 * at an article that does not point back.
 *
 * The first match wins. Two articles naming the same product would be a content
 * mistake rather than something to render twice, and blog_posts() is newest
 * first, so the newer one is the one shown.
 */
function post_for_product(string $slug): ?array {
    if ($slug === '') return null;
    foreach (blog_posts() as $p) {
        if ($p['product'] === $slug) return $p;
    }
    return null;
}

function products_save(array $items): void {
    set_setting('products.items', json_encode(array_values($items), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}

function products_removed_save(array $slugs): void {
    set_setting('products.removed', json_encode(array_values(array_unique($slugs)), JSON_UNESCAPED_SLASHES));
}

/* ---------- app settings (SMTP etc.) — stored in the content table ---------- */

function setting(string $k, string $default = ''): string {
    $all = content_all();
    return array_key_exists($k, $all) ? $all[$k] : $default;
}

function set_setting(string $k, string $v): void {
    content_set($k, $v);
}

/* ---------- email via SMTP (PHPMailer, self-hosted) ---------- */

/** Send an email using the admin-configured SMTP settings. Returns [ok, error]. */
function send_mail(string $subject, string $htmlBody, string $textBody, string $replyTo = '', string $replyName = ''): array {
    $host = setting('smtp.host');
    $to   = setting('smtp.to');
    if ($host === '' || $to === '') {
        return [false, 'Email is not configured yet. Set it up under Email / Forms in the admin.'];
    }
    require_once __DIR__ . '/lib/phpmailer/Exception.php';
    require_once __DIR__ . '/lib/phpmailer/PHPMailer.php';
    require_once __DIR__ . '/lib/phpmailer/SMTP.php';

    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = $host;
        $mail->Port = (int) (setting('smtp.port', '587') ?: 587);
        $secure = setting('smtp.secure', 'tls');
        if ($secure === 'ssl')      $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        elseif ($secure === 'tls')  $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        else                        { $mail->SMTPSecure = false; $mail->SMTPAutoTLS = false; }
        $user = setting('smtp.user');
        if ($user !== '') {
            $mail->SMTPAuth = true;
            $mail->Username = $user;
            $mail->Password = setting('smtp.pass');
        }
        $fromEmail = setting('smtp.from', $user ?: $to);
        $mail->setFrom($fromEmail, setting('smtp.from_name', 'ErikaKPage Website'));
        foreach (array_filter(array_map('trim', explode(',', $to))) as $rcpt) $mail->addAddress($rcpt);
        if ($replyTo !== '' && filter_var($replyTo, FILTER_VALIDATE_EMAIL)) $mail->addReplyTo($replyTo, $replyName);
        $mail->CharSet = 'UTF-8';
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $htmlBody;
        $mail->AltBody = $textBody;
        $mail->send();
        return [true, ''];
    } catch (\Throwable $e) {
        return [false, $mail->ErrorInfo ?: $e->getMessage()];
    }
}

/* ---------- auth & CSRF ---------- */

function installed(): bool {
    try {
        return (bool) db()->query('SELECT COUNT(*) AS c FROM users')->fetch()['c'];
    } catch (Throwable $e) {
        return false;
    }
}

function is_admin(): bool {
    return !empty($_SESSION['admin_id']);
}

function csrf_token(): string {
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(16));
}

function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400);
        exit('Bad request (invalid CSRF token). Go back and try again.');
    }
}

/* ---------- Lofty CRM (create a lead when a form is submitted) ---------- */

const LOFTY_ENDPOINT = 'https://api.lofty.com/v1.0/leads';

/** Per-form default Source + Tags (used until the admin overrides them). */
function lofty_form_defaults(): array {
    return [
        'sell'           => ['Website – Seller',        'Website,Seller'],
        'homevalue'      => ['Website – Home Value',    'Website,Seller,Home Value'],
        'buy'            => ['Website – Buyer',         'Website,Buyer'],
        'speaking'       => ['Website – Speaking',      'Website,Speaking'],
        'collaborations' => ['Website – Collaboration', 'Website,Collaboration'],
        'media'          => ['Website – Media',         'Website,Media'],
        'resources'      => ['Website – Checklist',     'Website,Lead Magnet'],
        'mentorship'     => ['Website – Mentorship',    'Website,Mentorship,Agent'],
        'investing'      => ['Website – Investing',     'Website,Investor'],
        'pm'             => ['Website – Property Mgmt', 'Website,Property Management'],
        'transportation' => ['Website – Transportation','Website,Transportation'],
        'contact'        => ['Website – Contact',       'Website,Contact'],
    ];
}

/** Stable per-form key shared by submit.php and the admin table. */
function form_key(string $page, string $formName): string {
    $s = strtolower($page . '-' . $formName);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim($s, '-');
}

function lofty_enabled(): bool {
    return setting('lofty.enabled') === '1' && trim(setting('lofty.key')) !== '';
}

/** Resolve the Source + Tags[] for a given form, honoring admin overrides. */
function lofty_mapping(string $page, string $formName): array {
    $fk = form_key($page, $formName);
    $defaults = lofty_form_defaults();
    [$dSource, $dTags] = $defaults[$page] ?? [setting('lofty.source_default', 'Website'), setting('lofty.tags_default', 'Website')];
    $source = setting('lofty.form.' . $fk . '.source', $dSource) ?: $dSource;
    $tagsRaw = setting('lofty.form.' . $fk . '.tags', $dTags);
    if ($tagsRaw === '') $tagsRaw = $dTags;
    $tags = array_values(array_filter(array_map('trim', explode(',', $tagsRaw))));
    $on = setting('lofty.form.' . $fk . '.on', '1') !== '0';
    return ['source' => $source, 'tags' => $tags, 'on' => $on];
}

/**
 * Create a lead in Lofty. Returns [ok, detail].
 * $lead: firstName, lastName, email, phone, source, tags[], note.
 * Never throws; short timeout so a slow API can't hang the thank-you page.
 */
/**
 * Low-level authenticated POST to Lofty. Returns [ok, httpCode, responseBody].
 * The Lofty API Reference documents `Authorization: Bearer <token>` on every
 * endpoint; we try Bearer first and fall back to the `token` scheme on a 401,
 * so it works whichever the account's key expects.
 */
function lofty_http(string $url, array $payload): array {
    $key = trim(setting('lofty.key'));
    $body = json_encode($payload);
    // A user-managed API Key authenticates as "Authorization: token <key>";
    // an OAuth access token uses "Bearer <token>". Try the API-key scheme first
    // (that's what the admin generates), then Bearer. A non-2xx never creates a
    // lead, so trying both schemes can't produce duplicates.
    $schemes = ['token ', 'Bearer '];
    $last = [false, 0, ''];
    foreach ($schemes as $scheme) {
        $headers = ['Authorization: ' . $scheme . $key, 'Content-Type: application/json', 'Accept: application/json'];
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_HTTPHEADER => $headers,
                CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_TIMEOUT => 10,
            ]);
            $resp = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $cErr = curl_error($ch);
            curl_close($ch);
            if ($resp === false) return [false, 0, 'Connection failed: ' . $cErr];
        } else {
            $ctx = stream_context_create(['http' => [
                'method' => 'POST', 'header' => implode("\r\n", $headers),
                'content' => $body, 'timeout' => 10, 'ignore_errors' => true,
            ]]);
            $resp = @file_get_contents($url, false, $ctx);
            $code = 0;
            if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) $code = (int) $m[1];
            if ($resp === false) return [false, 0, 'Connection failed'];
        }
        if ($code >= 200 && $code < 300) return [true, $code, (string) $resp];
        $last = [false, $code, (string) $resp];
        // fall through to the next auth scheme on any non-2xx (safe: nothing was created)
    }
    return $last;
}

/** Pull a lead id out of Lofty's response envelope, wherever it lives. */
function lofty_extract_lead_id(string $resp): string {
    $j = json_decode($resp, true);
    if (!is_array($j)) return '';
    $cands = [$j['data']['id'] ?? null, $j['data']['leadId'] ?? null, $j['data'] ?? null, $j['id'] ?? null, $j['leadId'] ?? null];
    foreach ($cands as $c) {
        if (is_int($c) || (is_string($c) && $c !== '')) return (string) $c;
    }
    return '';
}

/**
 * Create a lead in Lofty. Returns [ok, detail]. Never throws; short timeout.
 * $lead keys: firstName, lastName, email, phone, source, tags[], leadTypes[], note.
 *
 * Field names/shape match Lofty's Create Lead schema (POST /v1.0/leads):
 * emails/phones are arrays; the note is attached inline via `content` + `isPin`
 * (the create-lead body accepts a note), so no second request is needed.
 */
function send_to_lofty(array $lead, ?string $endpoint = null): array {
    $key = trim(setting('lofty.key'));
    if ($key === '') return [false, 'No Lofty API key set.'];
    $leadsUrl = $endpoint ?: (setting('lofty.endpoint', '') ?: LOFTY_ENDPOINT);

    $email = trim((string) ($lead['email'] ?? ''));
    $phone = trim((string) ($lead['phone'] ?? ''));
    // firstName is required by Lofty — fall back so email-only forms aren't rejected.
    $first = trim((string) ($lead['firstName'] ?? ''));
    if ($first === '') $first = $email !== '' ? explode('@', $email)[0] : 'Website Lead';
    $note = (string) ($lead['note'] ?? '');
    if (strlen($note) > 2000) $note = substr($note, 0, 1997) . '...';

    $payload = array_filter([
        'firstName' => $first,
        'lastName'  => $lead['lastName'] ?? '',
        'emails'    => $email !== '' ? [$email] : [],
        'phones'    => $phone !== '' ? [$phone] : [],
        'source'    => $lead['source'] ?? 'Website',
        'tags'      => $lead['tags'] ?? [],
        'leadTypes' => $lead['leadTypes'] ?? [],
    ], fn($v) => $v !== '' && $v !== []);
    if ($note !== '') {                 // inline note (create-lead accepts content + isPin)
        $payload['content'] = $note;
        $payload['isPin'] = false;
    }

    [$ok, $code, $resp] = lofty_http($leadsUrl, $payload);
    if (!$ok) return [false, ($code ? 'HTTP ' . $code . ': ' : '') . substr($resp, 0, 240)];

    $detail = 'lead HTTP ' . $code;
    $leadId = lofty_extract_lead_id($resp);
    if ($leadId !== '') $detail .= ' · lead #' . $leadId;
    if ($note !== '')   $detail .= ' · note attached';
    return [true, $detail];
}

/** Record one CRM sync attempt (best-effort; ignores errors). */
function crm_log_add(string $form, string $email, bool $ok, string $detail): void {
    try {
        $driver = cfg()['driver'] ?? 'mysql';
        if ($driver === 'sqlite') {
            db()->exec('CREATE TABLE IF NOT EXISTS crm_log (id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT, form TEXT, email TEXT, ok INTEGER, detail TEXT)');
        } else {
            db()->exec('CREATE TABLE IF NOT EXISTS crm_log (id INT AUTO_INCREMENT PRIMARY KEY, created DATETIME, form VARCHAR(160), email VARCHAR(160), ok TINYINT, detail TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        }
        db()->prepare('INSERT INTO crm_log (created, form, email, ok, detail) VALUES (?,?,?,?,?)')
            ->execute([date('Y-m-d H:i:s'), $form, $email, $ok ? 1 : 0, substr($detail, 0, 500)]);
    } catch (Throwable $e) { /* logging must never break a submission */ }
}

function crm_log_recent(int $limit = 25): array {
    try {
        $stmt = db()->query('SELECT * FROM crm_log ORDER BY id DESC LIMIT ' . (int) $limit);
        return $stmt->fetchAll();
    } catch (Throwable $e) { return []; }
}

/** Every website form as [page, name, key], read from index.php so it stays in sync. */
function all_forms(): array {
    static $forms;
    if ($forms !== null) return $forms;
    $forms = [];
    $seen = [];
    $html = @file_get_contents(__DIR__ . '/index.php') ?: '';
    if (preg_match_all('/name="_form" value="([^"]*)">\s*<input type="hidden" name="_page" value="([^"]*)"/', $html, $m, PREG_SET_ORDER)) {
        foreach ($m as $row) {
            $name = html_entity_decode($row[1], ENT_QUOTES);
            $page = $row[2];
            $fk = form_key($page, $name);
            if (isset($seen[$fk])) continue;
            $seen[$fk] = true;
            $forms[] = ['page' => $page, 'name' => $name, 'key' => $fk];
        }
    }
    return $forms;
}

/* ---------- uploads ---------- */

const MAX_UPLOAD_BYTES = 300 * 1024 * 1024; // 300 MB

function handle_upload(array $file): array {
    // returns [path, error]
    if ($file['error'] === UPLOAD_ERR_NO_FILE) return ['', ''];
    if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
        return ['', 'File is too large for the server limit. Ask the host to raise upload_max_filesize / post_max_size.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) return ['', 'Upload failed (code ' . $file['error'] . ').'];
    if ($file['size'] > MAX_UPLOAD_BYTES) return ['', 'File is larger than 300 MB.'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    // Several of these have more than one MIME type in the wild — an .m4a is an
    // MP4 container, so finfo may call it audio/mp4, audio/x-m4a or video/mp4 —
    // so each extension carries the list of types that genuinely belong to it.
    $allowed = [
        'jpg'  => ['image/jpeg'], 'jpeg' => ['image/jpeg'], 'png' => ['image/png'],
        'webp' => ['image/webp'], 'gif'  => ['image/gif'],
        'mp4'  => ['video/mp4'],  'webm' => ['video/webm'],
        'pdf'  => ['application/pdf'],
        'mp3'  => ['audio/mpeg', 'audio/mp3', 'application/octet-stream'],
        'm4a'  => ['audio/mp4', 'audio/x-m4a', 'video/mp4'],
    ];
    if (!isset($allowed[$ext])) return ['', 'Only JPG, PNG, WEBP, GIF, MP4, WEBM, MP3, M4A or PDF files are allowed.'];

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!in_array($mime, $allowed[$ext], true)) return ['', 'File content does not match its extension.'];

    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    $dir = __DIR__ . '/uploads';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    if (!move_uploaded_file($file['tmp_name'], "$dir/$name")) return ['', 'Could not save the file.'];

    // Build the scaled-down copies straight away, so a picture uploaded here is
    // as light on a phone as the ones that ship with the site. A failure here is
    // not fatal: cms_img() serves the original when no copies exist.
    if (!in_array($ext, ['mp4', 'webm', 'pdf', 'mp3', 'm4a'], true)) {
        require_once __DIR__ . '/lib/imgvariants.php';
        img_build_variants(__DIR__, 'uploads/' . $name);
    }

    return ['uploads/' . $name, ''];
}
